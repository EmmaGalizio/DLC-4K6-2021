package tpi.dlc.tpidlcmotorbusquedaficheros.indexation.postingListReader;

import tpi.dlc.tpidlcmotorbusquedaficheros.indexation.structure.VocabularySlot;

public interface PostingListReader {

    void loadPostingList(VocabularySlot vocabularySlot);

}
