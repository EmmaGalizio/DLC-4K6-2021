
package clases;

import java.util.ArrayList;

/**
 * La clase permite gestionar en forma simple un grafo de n vértices, no 
 * dirigido y no ponderado. La implementación es matricial, asumiendo que los 
 * vértices contienen directamente los números entre 1 y n, por lo que la 
 * representación completa del grafo se realiza sólo con la matriz de 
 * adyacencias, en la cual se almacenan directamente valores 1 y 0 para 
 * indicar la presencia de un arco o no. La fila k-1 (con k en [1..n]) de la 
 * matriz se usa para registrar los arcos de partida del vértice con valor k, 
 * así como la columna k-1 registra los arcos de llegada del vértice k.
 * 
 * La clase se utiliza para presentar y testear en forma simple algunos 
 * algoritmos clásicos de orden exponencial en el ámbito de la complejidad 
 * computacional, además de presentar el concepto de reducción polinómica.
 * 
 * @author Ing. Valerio Frittelli.
 * @version Junio de 2014.
 */
public class MatrixGraph 
{
    // la matriz que representa al grafo...
    private int graph[][];
    
    // el arreglo que representa a un clique máximo del grafo...
    private int max_clique[];
    
    // la cantidad de vértices del clique máximno...
    private int max_clique_value;
    
    // el arreglo que representa a una cobertura mínima del grafo...
    private int min_vertex_cover[];
    
    // la cantidad de vértices de la cobertura mínima...
    private int min_vertex_cover_value;
    
    // el arreglo que representa a un subconjunto independiente máximo...    
    private int max_independent_set[];
    
    // la cantidad de vértices del subconjunto independiente máximo...    
    private int max_independent_set_value;
    
    /**
     * Crea un MatrixGraph para 5 vértices, con todos los casilleros en 0. Se
     * considera que los vértices serán efectivamente los valores en [1..5]. 
     */    
    public MatrixGraph()
    {
        this(5);
    }
    
    /**
     * Crea un MatrixGraph para n vértices, con todos los casilleros en 0. La 
     * matriz de adyacencias tendrá n*n casillas. Se considera que los vértices 
     * serán efectivamente los valores en [1..n].
     * @param n la cantidad de vértices del grafo.
     */
    public MatrixGraph(int n)
    {
        if(n <= 0) { n = 5; }
        this.graph = new int[n][n];
    }
    
    /**
     * Crea un MatrixGraph a partir de una matriz <b>g<\b> de valores int ya 
     * creada e inicializada. Se supone que g no es null, y que cada casilla 
     * g[i][j] vale 0 o 1, sin validar ninguno de ambos supuestos.
     * @param g la matriz a partir de la cual se crea el MatrixGraph.
     */
    public MatrixGraph(int g[][])
    {   
        int n = g.length;
        this.graph = new int[n][n];
        
        for(int f = 0; f < n; f++)
        {
            System.arraycopy(g[f], 0, this.graph[f], 0, n);
        }
    }
    
    /**
     * Retorna la cantidad de vértices del grafo.
     * @return la cantidad de vértices del grafo.
     */
    public int countVertices()
    {
        return this.graph.length;
    }
    
    /**
     * Retorna un clique máximo de vértices para el grafo de n vértices, 
     * representado por un arreglo de n casillas de tipo int. Si el vértice k 
     * (con k en [1..n]) pertenece al clique retornado, entonces el casillero 
     * k-1 del arreglo retornado valdrá 1 (y valdrá 0 en caso contrario).
     * @return un arreglo con un clique máximo de vértices para el grafo.
     */
    public int[] getMaxClique()
    {
        if(this.max_clique == null) { this.compute_clique(); }
        return this.max_clique;
    }
    
    /**
     * Retorna la cantidad de vértices incluidos en el clique máximo para el 
     * grafo, obtenido con el método getMaxClique().
     * @return el número de vértices incluidos en el clique máximo.
     */
    public int getMaxCliqueValue()
    {
        if(this.max_clique == null) { this.compute_clique(); }
        return this.max_clique_value;
    }
    
    /**
     * Retorna un subconjunto independiente máximo de vértices para el grafo de 
     * n vértices, representado por un arreglo de n casillas de tipo int. Si el 
     * vértice k (con k en [1..n]) pertenece al IS retornado, entonces el 
     * casillero k-1 del arreglo retornado valdrá 1 (y valdrá 0 en caso 
     * contrario).
     * @return un arreglo con un subconjunto independiente máximo de vértices para el grafo.
     */
    public int[] getMaxIndependentSet()
    {
        if(this.max_independent_set == null) { this.compute_independent_set(); }
        return this.max_independent_set;
    }
    
    /**
     * Retorna la cantidad de vértices incluidos en el subconjunto independiente 
     * máximo para el grafo, obtenido con el método getMaxIndependentSet().
     * @return el número de vértices incluidos en el subconjunto independiente.
     */
    public int getMaxIndependentSetValue()
    {
        if(this.max_independent_set == null) { this.compute_independent_set(); }
        return this.max_independent_set_value;
    }
    
    /**
     * Retorna una cobertura mínima de vértices para el grafo de n vértices, 
     * representada por un arreglo de n casillas de tipo int. Si el vértice k
     * (con k en [1..n]) pertenece a la cobertura mínima retornada, entonces el 
     * casillero k-1 del arreglo retornado valdrá 1 (y valdrá 0 en caso 
     * contrario).
     * @return un arreglo con una cobertura mínima de vértices para el grafo.
     */
    public int[] getMinVertexCover()
    {
        if(this.min_vertex_cover == null) { this.compute_vertex_cover(); }
        return this.min_vertex_cover;
    }
    
    /**
     * Retorna la cantidad de vértices incluidos en la cobertura de vértices 
     * mínima para el grafo, obtenida con el método getMinVertexCover().
     * @return el número de vértices incluidos en la cobertura mínima.
     */
    public int getMinVertexCoverValue()
    {
        if(this.min_vertex_cover == null) { this.compute_vertex_cover(); }
        return this.min_vertex_cover_value;
    }
    
    /**
     * Retorna la conversión a String del arreglo que representa un clique 
     * máximo para el grafo (obtenido con el método getMaxClique()). 
     * @return un String representando un clique máximo del grafo.
     */
    public String toStringMaxClique()
    {
        if(this.max_clique == null) { this.compute_clique(); }
        return this.to_string_array(this.max_clique);
    }    

    /**
     * Retorna la conversión a String del arreglo que representa un subconjunto
     * independiente mínimo para el grafo (obtenido con el método 
     * getMinindependentSet()). 
     * @return un String representando un subconjunto independiente mínimo del grafo.
     */
    public String toStringMaxIndependentSet()
    {
        if(this.max_independent_set == null) { this.compute_independent_set(); }
        return this.to_string_array(this.max_independent_set);
    }    
    
    /**
     * Retorna la conversión a String del arreglo que representa una cobertura
     * mínima para el grafo (obtenida con el método getMinVertexCover()). 
     * @return un String representando la cobertura mínima del grafo.
     */
    public String toStringMinVertexCover()
    {
        if(this.min_vertex_cover == null) { this.compute_vertex_cover(); }
        return this.to_string_array(min_vertex_cover);
    }
    
    @Override
    public String toString()
    {
        int n = this.graph.length;
        
        StringBuilder r = new StringBuilder("[\n");
        for(int f = 0; f < n; f++)
        {
            r.append("\t[ ");
            for(int c = 0; c < n; c++)
            {
                r.append(this.graph[f][c]).append(" ");
            }
            r.append("]\n");
        }
        r.append("]");
        return r.toString();
    }
    
    /**
     * Calcula un clique máximo de vértices para el grafo. La lista de vértices 
     * que forman ese clique máximo, se puede obtener con el método 
     * getMaxClique(), y la cantidad de vértices de ese clique se puede obtener 
     * con el método getMaxCliqueValue().
     */
    private void compute_clique()
    {
        // el clique es el independent set máximo en el grafo invertido...
        // ...por lo que creamos un grafo con la matriz invertida del original...
        MatrixGraph inv = new MatrixGraph(this.invert());

        // ...obtenemos y guardamos el IS máximo del grafo invertido... 
        this.max_clique = inv.getMaxIndependentSet();
        this.max_clique_value = inv.getMaxIndependentSetValue();
    }
    
    /**
     * Calcula un subconjunto independiente (IS) máximo de vértices para el 
     * grafo. La lista de vértices que forman ese IS máximo se puede obtener con 
     * el método getMaxIndependentSet(), y la cantidad de vértices de ese IS se 
     * puede obtener con el método getMaxIndependenteSetValue().
     */
    private void compute_independent_set()
    {
        // obtener la cantidad de vértices del grafo...
        int n = this.graph.length;
                
        // ... obtener el vertex cover del grafo...        
        if(this.min_vertex_cover == null) { this.compute_vertex_cover(); }
        
        // ...crear el IS, con los vértices que NO ESTABAN en el vertex cover...
        this.max_independent_set_value = 0;
        this.max_independent_set = new int[n];
        for(int v = 0; v < n; v++)           
        {
            this.max_independent_set[v] = 1 - this.min_vertex_cover[v];
            if(this.max_independent_set[v] == 1) { this.max_independent_set_value++; }
        }
    }

    /**
     * Calcula una cobertura mínima de vértices para el grafo. La lista de 
     * vértices que forman esa cobertura mínima se puede obtener con el método
     * getMinVertexCover(), y la cantidad de vértices de esa cobertura se puede
     * obtener con el método getMinVertexCoverValue().
     */
    private void compute_vertex_cover()
    {
        int vc = 0;
        int n = this.graph.length;
        this.min_vertex_cover_value = n;
        
        // iterar todos los subconjuntos candidatos del conjunto de vértices...
        ArrayList<Integer> cp = this.power_set();
        for(int candidate : cp)
        {
            // chequear si el conjunto candidate es una cobertura válida...
            if(this.validity_check(candidate))
            {
                // calcular el tamaño (cantidad de bits en 1) de candidate...
                int size = Integer.bitCount(candidate);
                
                // actualizar el mínimo si corresponde...
                if(size < this.min_vertex_cover_value) 
                { 
                    vc = candidate;
                    this.min_vertex_cover_value = size; 
                    
                    // si la lista cp está ordenada por cantidad de bits
                    // en 1 de menor a mayor, entonces el primer candidate que
                    // que aparezca es el menor posible y podemos cortar...
                    // ... si la lista NO está ordenada, comentarizar el break...
                    //break;
                }
            }
        }
        
        // convertir el valor candidate a un arreglo de valores int...
        this.min_vertex_cover = new int[n];
        int m = 1; // m = 00000001
        for(int i = 0; i < n; i++)
        {
            this.min_vertex_cover[i] = ((vc & m) == 0)? 0 : 1;
            m = m << 1;
        }        
    }
    
    /**
     * Retorna una matriz que representa al grafo actual invertido: todos los 
     * unos del grafo original se cambian por ceros, y todos los ceros por unos
     * (salvo en la diagonal).
     * #return una matriz que representa al grafo invertido. 
     */
    private int[][] invert()
    {
        int n = this.graph.length;
        int out[][] = new int[n][n];

        for(int f = 0; f < n - 1; f++)
        {         
            for(int c = f + 1; c < n; c++)
            {
                out[f][c] = 1 - this.graph[f][c];
                out[c][f] = out[f][c];
            }
        }

        return out;
    }
    
    /**
     * Genera una lista con todos los subconjuntos posibles de combinar los n
     * vértices del grafo. Es decir, genera una lista que equivale al conjunto
     * potencia del conjunto de vértices del grafo. 
     * @return una lista con todos los subconjuntos posibles del conjunto de 
     *         vértices del grafo.
     */
    private ArrayList<Integer> power_set()
    {
        int n = this.graph.length;
        int t = (int) Math.pow(2, n);

        // crear la lista con los números que representan a los subconjuntos...
        ArrayList<Integer> s = new ArrayList<>();
        for(int x = 0; x <= t-1; x++)
        {
            s.add(x);
        }     
        
        /*
        // ordenar la lista según la cantidad de bits en 1 que tiene cada valor...
        Collections.sort(s, new Comparator<Integer>()
                            {
                                @Override
                                public int compare(Integer o1, Integer o2) 
                                {
                                    int b1 = Integer.bitCount(o1);
                                    int b2 = Integer.bitCount(o2);
                                    return b1 - b2;
                                }
                            }
        );
        //*/
        
        // retornar la lista ordenada...
        return s;
    }    
    
    /**
     * Retorna la conversión a String del arreglo v tomado como parámetro.
     * @param v un arreglo enteros.
     * @return la conversión a String del arreglo v.
     */
    private String to_string_array(int v[])
    {
        int n = v.length;
        StringBuilder r = new StringBuilder("[");
        for(int i = 0; i < n; i++)
        {
            r.append(v[i]);
            if(i != n-1) { r.append(", "); }
        }
        r.append("]");
        return r.toString();    
    }
    
    /** Chequea si la combinación de vértices representada por el parámetro 
     * <b>candidate<\b> es una cobertura de vértices válida para el grafo 
     * (retorna true en ese caso) o no (retorna false). El parámetro candidate
     * es un número entero cuyo valor está contenido en el intervalo [0..2^n], 
     * de forma tal que si el vértice k (con k en [1..n]) pertenece a la 
     * cobertura que se propone, entonces el k-ésimo bit desde la derecha en la 
     * representación binaria del valor candidate valdrá 1 (o valdrá 0 en caso 
     * contrario). 
     * @param candidate un número entero positivo que representa la cobertura 
     *                  propuesta.
     * @return true si candidate es una cobertura válida para el grafo.
    */
    private boolean validity_check(int candidate)
    {
        int n = this.graph.length;
        for(int f = 0; f < n - 1; f++)
        {           
            for(int c = f + 1; c < n; c++)
            {
                // si hay un arco entre f y c...
                if(this.graph[f][c] == 1)
                { 
                    
                    // recordar: la fila f representa al vértice que vale f+1...
                    // sería: int rf = candidate & (1 << ((f + 1) - 1));
                    int rf = candidate & (1 << f);
                    
                    // ... y la columna c al vértice que vale c+1...
                    // sería: int rc = candidate & (1 << ((c + 1) - 1));
                    int rc = candidate & (1 << c);                    
                    
                    // ... si ninguno está en candidate, salir con false...
                    if(rf == 0 && rc == 0) { return false; } 
                }
            }
        }
        
        // si llegamos acá, candidate es una cobertura válida...
        return true; 
    }    
}
